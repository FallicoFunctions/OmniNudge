"""Strand optics and scalp-shell clearance on the preserved curl geometry.
Connection map: dark scalp shell shrinkwraps to actual head plus 1.5 mm;
strand roots overlap that shell. Visible curl coordinates remain unchanged.
"""
import bpy,json
from pathlib import Path
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'face19.blend'))
cap=bpy.data.objects['Proof_Scalp18Surface']
modifier=cap.modifiers.new('Measured scalp clearance','SHRINKWRAP')
modifier.target=bpy.data.objects['AvatarBody'];modifier.wrap_method='NEAREST_SURFACEPOINT';modifier.offset=.0015
for ob in bpy.data.objects:
    if not ob.name.startswith('Proof_Curl18_'):continue
    shade=int(ob.name[-1]);mat=ob.data.materials[0].copy();ob.data.materials[0]=mat
    tree=mat.node_tree;bs=tree.nodes.new('ShaderNodeBsdfHairPrincipled');bs.parametrization='MELANIN'
    bs.inputs['Melanin'].default_value=[.94,.88,.78,.64,.48][shade]
    bs.inputs['Melanin Redness'].default_value=.17
    bs.inputs['Tint'].default_value=(.25,.20,.16,1)
    bs.inputs['Roughness'].default_value=.34
    bs.inputs['Radial Roughness'].default_value=.4
    bs.inputs['Random Roughness'].default_value=.12
    tree.links.new(bs.outputs[0],tree.nodes['Material Output'].inputs['Surface'])
scene=bpy.context.scene;scene.cycles.samples=128;scene.render.filepath=str(OUT/'renders/optics20-reference-angle.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'optics20.blend'));bpy.ops.render.render(write_still=True)
(OUT/'landmarks/optics20.json').write_text(json.dumps({'control':'face19','curl_coordinates':'unchanged','changes':['Principled Hair BSDF for visible curl strands','scalp shell shrinkwrap with 1.5 mm clearance'],'likeness':'unaccepted'},indent=2)+'\n')
print('OPTICS20_COMPLETE')
