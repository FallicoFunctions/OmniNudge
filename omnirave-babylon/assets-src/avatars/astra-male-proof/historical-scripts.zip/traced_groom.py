"""Authored 3D guide locks traced from the original artwork.

Connection map: front curls start at the hairline and overlap the scalp volume.
Their depths follow the head volume; inferred back locks fill the unseen occiput.
Each lock has layered strand cards around an elliptical section, sharing head skin.
The original image contributes coordinates only, never projected colors.
"""
import bpy,math,json,random
from pathlib import Path
from mathutils import Vector

def build(out):
    p=json.loads((out/'landmarks/fit05-deformation.json').read_text())['pose']
    yaw,pitch,roll=p['yaw'],p['pitch'],p['roll'];scale=p['pixels_per_meter']
    r=Vector((math.cos(yaw),math.sin(yaw),0))
    u=Vector((-math.sin(pitch)*math.sin(yaw),math.sin(pitch)*math.cos(yaw),math.cos(pitch)))
    right=r*math.cos(roll)+u*math.sin(roll);down=r*math.sin(roll)-u*math.cos(roll)
    outward=right.cross(-down).normalized(); center=Vector(p['center'])
    def world(point):
        x,y,depth=point
        return center+right*((x-p['translation'][0])/scale)+down*((y-p['translation'][1])/scale)+outward*depth
    # Pixel knots are recorded in the native 1024x1536 reference coordinate system.
    # Depth is a provisional local inference in meters, constrained by profile views.
    guides=[
      {'name':'central-rise','knots':[(514,122,.088),(522,108,.069),(517,89,.028),(502,82,.004),(486,90,.015),(480,108,.067),(482,122,.102)],'width':6.3,'shade':1},
      {'name':'left-golden-wave','knots':[(499,124,.096),(500,108,.073),(489,95,.045),(474,97,.040),(464,113,.065),(463,135,.092),(451,153,.101)],'width':6.5,'shade':2},
      {'name':'outer-left-curl','knots':[(491,109,.050),(476,90,.008),(459,100,.017),(449,119,.036),(450,140,.066),(444,153,.088),(432,148,.071)],'width':5.5,'shade':2},
      {'name':'crown-left','knots':[(518,113,.054),(528,96,.027),(519,81,-.005),(501,76,-.018),(481,81,-.020),(465,97,.004)],'width':6.0,'shade':1},
      {'name':'crown-crest','knots':[(529,112,.051),(539,96,.020),(534,84,-.027),(517,76,-.043),(503,75,-.038)],'width':5.2,'shade':1},
      {'name':'upper-right-wave','knots':[(521,118,.076),(540,117,.056),(552,108,.010),(545,93,-.032),(532,87,-.047)],'width':6.3,'shade':0},
      {'name':'right-temple-sweep','knots':[(518,126,.095),(536,134,.086),(552,143,.065),(565,145,.035),(575,150,.006),(577,159,-.006)],'width':5.5,'shade':0},
      {'name':'right-high-sweep','knots':[(522,118,.074),(543,125,.054),(560,128,.022),(572,123,-.020),(568,112,-.046),(556,104,-.049)],'width':5.0,'shade':1},
      {'name':'right-middle','knots':[(532,127,.068),(551,134,.043),(571,140,.008),(581,151,-.027),(578,164,-.041)],'width':5.5,'shade':0},
      {'name':'right-back','knots':[(547,119,.026),(566,125,-.023),(582,141,-.053),(585,161,-.055),(578,179,-.047)],'width':5.5,'shade':0},
      {'name':'back-edge','knots':[(555,121,-.043),(577,136,-.075),(588,156,-.075),(585,176,-.057),(573,189,-.030)],'width':5.0,'shade':0},
      {'name':'left-brow-fall','knots':[(478,110,.070),(472,124,.087),(475,143,.116),(468,159,.123),(456,163,.101)],'width':3.4,'shade':2},
      {'name':'part-stray','knots':[(516,117,.096),(521,128,.121),(519,144,.139),(513,151,.145)],'width':2.0,'shade':1},
      {'name':'left-fringe-tip','knots':[(458,118,.043),(450,134,.070),(450,155,.102),(439,169,.112),(433,165,.103)],'width':3.6,'shade':1},
    ]
    (out/'landmarks/hair-guide-traces.json').write_text(json.dumps({'authority':'reference-original.png','depths':'inferred, must pass profile review','guides':guides},indent=2)+'\n')
    # Keep only the fitted scalp underlayer from the prior study; dense generic
    # cards would flatten the authored curls. It is hidden under the new bundles.
    old=bpy.data.objects.get('Proof_HairCards')
    if old:old.hide_render=True;old.hide_set(True)
    cap=bpy.data.objects.get('Proof_HairVolume')
    if cap:
        for v in cap.data.vertices:
            # Expose the natural forehead; no artificial broad side-swept fringe.
            if v.co.y<-.07 and v.co.z>1.69:v.co.z-=.010
    texture=bpy.data.images['Proof_HairStrands']
    mats=[]
    for shade,mult in enumerate([(1.0,.90,.83),(1.8,1.65,1.45),(3.4,2.8,1.9)]):
        mat=bpy.data.materials.new('TraceHair_'+str(shade));mat.use_nodes=True;mat.surface_render_method='DITHERED'
        tree=mat.node_tree;b=tree.nodes['Principled BSDF'];tex=tree.nodes.new('ShaderNodeTexImage');tex.image=texture
        tint=tree.nodes.new('ShaderNodeMixRGB');tint.blend_type='MULTIPLY';tint.inputs[0].default_value=1;tint.inputs[2].default_value=(*mult,1)
        tree.links.new(tex.outputs['Color'],tint.inputs[1]);tree.links.new(tint.outputs[0],b.inputs['Base Color']);tree.links.new(tex.outputs['Alpha'],b.inputs['Alpha'])
        b.inputs['Roughness'].default_value=.60;b.inputs['Specular IOR Level'].default_value=.22
        b.inputs['Specular Tint'].default_value=(.45,.29,.16,1)
        mats.append(mat)
    core=bpy.data.materials.new('TraceHairCore');core.use_nodes=True
    cb=core.node_tree.nodes['Principled BSDF'];cb.inputs['Base Color'].default_value=(.024,.012,.006,1)
    cb.inputs['Roughness'].default_value=.8;cb.inputs['Specular IOR Level'].default_value=.1;mats.append(core)
    vs=[];fs=[];uvs=[];mi=[];rng=random.Random(908)
    def spline(knots,t):
        f=min(t*(len(knots)-1),len(knots)-1-1e-7);j=int(f);s=f-j
        a=knots[max(0,j-1)];b=knots[j];c=knots[min(len(knots)-1,j+1)];d=knots[min(len(knots)-1,j+2)]
        return .5*((2*b)+(-a+c)*s+(2*a-5*b+4*c-d)*s*s+(-a+3*b-3*c+d)*s*s*s)
    def bundle(knots,width,shade,count=22):
        knots=[world(q) for q in knots]
        # A dark internal volume supports the translucent strand layers. Its
        # tapered section is buried inside the cards, never a flat painted shell.
        base=len(vs);steps=64;sides=12
        for j in range(steps+1):
            t=j/steps;c=spline(knots,t)
            tangent=(spline(knots,min(1,t+.0003))-spline(knots,max(0,t-.0003))).normalized()
            across=tangent.cross(outward).normalized();normal=across.cross(tangent).normalized()
            taper=min(1,.35+t*5)*(1-t**3)**.65+.025
            for k in range(sides):
                a=2*math.pi*k/sides
                vs.append(c+across*math.cos(a)*width*.38*taper+normal*math.sin(a)*width*.24*taper)
                uvs.append((k/(sides-1),t))
        for j in range(steps):
            for k in range(sides):
                a=base+j*sides+k;b=base+j*sides+(k+1)%sides
                fs.append((a,b,b+sides,a+sides));mi.append(3)
        for k in range(count):
            angle=2*math.pi*k/count
            radius=rng.uniform(.55,1)
            start=len(vs);steps=64
            for j in range(steps+1):
                t=j/steps;c=spline(knots,t)
                tangent=(spline(knots,min(1,t+.0003))-spline(knots,max(0,t-.0003))).normalized()
                across=tangent.cross(outward).normalized();normal=across.cross(tangent).normalized()
                taper=min(1,.35+t*5)*(1-t**3)**.65+.025
                c+=across*(math.cos(angle)*width*.5*radius*taper)+normal*(math.sin(angle)*width*.30*radius*taper)
                c+=normal*(math.sin(t*15+k)*.0008*math.sin(math.pi*t))
                cardwidth=width*.22*taper
                for s in range(3):
                    u=s/2;vs.append(c+across*(u-.5)*cardwidth+normal*math.sin(math.pi*u)*.00035)
                    uvs.append((u,t))
            for j in range(steps):
                for s in range(2):
                    a=start+j*3+s;fs.append((a,a+1,a+4,a+3));mi.append(shade)
    for g in guides:
        # Broad curls carry the hair mass; the narrow forehead tips stay fine.
        w=g['width']*(1.9 if g['width']>4 else 1.2)/scale
        bundle(g['knots'],w,g['shade'],count=30)
        if g['width']>4:
            under=[(x+2,y+6,d-.008) for x,y,d in g['knots']]
            bundle(under,w*.9,0,count=14)
    # Unseen/back coverage follows the skull rather than the picture plane.
    # These shorter locks are provisional but retain full 3D silhouette continuity.
    for i in range(35):
        th=.2+i/34*5.8
        points=[]
        for j in range(5):
            ph=.65+j*.28;x=.088*math.sin(ph)*math.sin(th);y=-.025+.098*math.sin(ph)*math.cos(th);z=1.65+.102*math.cos(ph)
            w=Vector((x,y,z));q=w-center
            points.append((p['translation'][0]+q.dot(right)*scale,p['translation'][1]+q.dot(down)*scale,q.dot(outward)))
        bundle(points,.008,0,count=7)
    me=bpy.data.meshes.new('TracedGroom');me.from_pydata(vs,[],fs);me.update()
    ob=bpy.data.objects.new('Proof_TracedGroom',me);bpy.context.scene.collection.objects.link(ob)
    for m in mats:me.materials.append(m)
    uv=me.uv_layers.new(name='UVMap')
    for poly in me.polygons:
        poly.use_smooth=True;poly.material_index=mi[poly.index]
        for li in poly.loop_indices:uv.data[li].uv=uvs[me.loops[li].vertex_index]
    ob.vertex_groups.new(name='head').add(list(range(len(vs))),1,'REPLACE')
    ob.modifiers.new('Head skin','ARMATURE').object=bpy.data.objects['AvatarSkeleton'];ob.parent=bpy.data.objects['AvatarSkeleton']
    print('TRACED_GROOM',len(vs),'vertices',sum(len(p.vertices)-2 for p in me.polygons),'triangles')
