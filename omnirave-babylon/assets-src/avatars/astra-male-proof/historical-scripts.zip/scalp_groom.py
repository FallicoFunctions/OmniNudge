"""Scalp-grown strand field, preserving the measured facial checkpoint.

Connection map before geometry creation:
  strand roots <-> evaluated head: roots embedded 0.6 mm in measured surface;
  adjacent root patches: uniformly sampled continuous scalp domain;
  groom <-> head bone: explicit world-rest matrix, shared head attachment.
Fine hair uses submillimetre embedding rather than structural 5 mm overlap.
"""
import bpy, math, random, json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

OUT = Path(__file__).resolve().parents[2] / 'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT / 'fit05.blend'))
for ob in bpy.data.objects:
    if ob.name.startswith(('Proof_Hair', 'AvatarHair')):
        ob.hide_render = True
bpy.data.objects['AvatarEyelashes'].hide_render = True
scene = bpy.context.scene
body = bpy.data.objects['AvatarBody']
bvh = BVHTree.FromObject(body, bpy.context.evaluated_depsgraph_get())
center = Vector((0, -.045, 1.651))
rng = random.Random(912)
strands = [[] for _ in range(5)]
root_errors = []

def surface(n):
    hit, normal, _, _ = bvh.ray_cast(center + n * .3, -n, .4)
    if hit is None:
        raise RuntimeError('Scalp ray missed the head')
    return hit, normal

for i in range(23000):
    theta = rng.uniform(-math.pi, math.pi)
    # Hairline lifts above the forehead and temples, tapering to the nape.
    end = 1.16 + .99 * ((1 - math.cos(theta)) * .5) ** .72
    phi = math.acos(rng.uniform(math.cos(end), 1))
    n = Vector((math.sin(phi)*math.sin(theta), -math.sin(phi)*math.cos(theta), math.cos(phi)))
    root, _ = surface(n)
    top = max(0, min(1, (root.z - 1.672) / .045))
    front = max(0, min(1, (-root.y + .005) / .14))
    left = root.x < -.012
    length = rng.uniform(.065, .105) if top > .2 else rng.uniform(.036, .064)
    # Nearby roots share a wave; each strand has small independent variations.
    phase = 9 * theta + 7 * phi
    amp = (.008 + .010 * top) * rng.uniform(.8, 1.2)
    independent = rng.random() * math.tau
    points = []
    steps = 38
    for j in range(steps + 1):
        t = j / steps
        p, normal = surface(n)
        lift = -.0006 * (1-t)**12 + (.003 + amp) * math.sin(math.pi*t)**.85
        lift += .0035 * math.sin(t*math.tau*1.5 + phase) * math.sin(math.pi*t)
        # The side flow follows the skull; longer top hairs sweep leftward.
        axis = Vector((-1.1*top, .30 + .25*(1-front), -.55*(1-top)-.24*t))
        if top < .2:
            axis.x = -.16 if left else .13
        tangent = axis - n * axis.dot(n)
        if tangent.length < .01:
            tangent = Vector((-1, .15, 0))
        tangent.normalize()
        across = n.cross(tangent).normalized()
        curl = (.003 + .004*top) * math.sin(t*8 + phase) * math.sin(math.pi*t)
        jitter = .00045 * math.sin(t*26 + independent) * math.sin(math.pi*t)
        points.append(p + normal*lift + across*(curl+jitter))
        n = (n + tangent*(length / steps / .095)).normalized()
    root_errors.append((points[0]-root).length)
    highlighted = front > .6 and top > .3 and math.sin(phase) > .5
    shade = rng.choices(range(5), [7, 5, 2, .5, .08] if not highlighted else [3, 4, 3, 1.5, .3])[0]
    strands[shade].append((points, rng.uniform(.000032, .000060)))

all_points = []
for shade, entries in enumerate(strands):
    cu = bpy.data.hair_curves.new('ScalpFieldStrands' + str(shade))
    cu.add_curves([len(points) for points, _ in entries])
    positions, radii = [], []
    for points, radius in entries:
        for j, p in enumerate(points):
            positions.extend(p)
            all_points.append(p)
            radii.append(radius * max(.025, (1-j/(len(points)-1))**.45))
    cu.attributes['position'].data.foreach_set('vector', positions)
    cu.attributes.new('radius', 'FLOAT', 'POINT').data.foreach_set('value', radii)
    mat = bpy.data.materials.new('ScalpFieldPigment' + str(shade))
    mat.use_nodes = True
    tree = mat.node_tree
    bs = tree.nodes.new('ShaderNodeBsdfHairPrincipled')
    bs.parametrization = 'MELANIN'
    bs.inputs['Melanin'].default_value = [.96, .90, .80, .65, .48][shade]
    bs.inputs['Melanin Redness'].default_value = .2
    bs.inputs['Tint'].default_value = (.24, .19, .15, 1)
    bs.inputs['Roughness'].default_value = .38
    bs.inputs['Radial Roughness'].default_value = .4
    tree.links.new(bs.outputs[0], tree.nodes['Material Output'].inputs['Surface'])
    cu.materials.append(mat)
    ob = bpy.data.objects.new('Proof_ScalpField' + str(shade), cu)
    scene.collection.objects.link(ob)
    ob.parent = bpy.data.objects['AvatarSkeleton']
    ob.parent_type = 'BONE'
    ob.parent_bone = 'head'
    bpy.context.view_layer.update()
    ob.matrix_world.identity()

report = {'checkpoint': 'scalp12', 'root_count': len(root_errors),
          'root_surface_distance_max_m': max(root_errors),
          'bounds_world': [[min(p[k] for p in all_points), max(p[k] for p in all_points)] for k in range(3)],
          'scope': 'authoring groom; likeness and runtime acceptance pending'}
(OUT / 'landmarks/scalp12-geometry.json').write_text(json.dumps(report, indent=2)+'\n')
scene.cycles.samples = 96
scene.render.filepath = str(OUT / 'renders/scalp12-reference-angle.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT / 'scalp12.blend'))
bpy.ops.render.render(write_still=True)
print('SCALP12_COMPLETE', report)
