"""Separate the close scalp undercoat from the visible curl silhouette.
Connection map: undercoat lies 0.5–2 mm above actual scalp, with original roots
retained. Curl guides remain unchanged, providing a controlled geometry test.
"""
import bpy,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'curl13.blend'))
scene=bpy.context.scene;tree=BVHTree.FromObject(bpy.data.objects['AvatarBody'],bpy.context.evaluated_depsgraph_get())
center=Vector((0,-.045,1.651));changed=0
for ob in bpy.data.objects:
    if not ob.name.startswith('Proof_ScalpField'):continue
    for curve in ob.data.curves:
        points=curve.points
        for j,pt in enumerate(points):
            q=pt.position.copy();n=(q-center).normalized()
            hit,normal,_,_=tree.ray_cast(center+n*.3,-n,.4)
            if hit is None:continue
            clearance=-.0006 if j==0 else .0015
            pt.position=hit+normal*clearance;changed+=1
    mat=ob.data.materials[0].copy();ob.data.materials[0]=mat
    bs=mat.node_tree.nodes['Principled BSDF'];bs.inputs['Specular IOR Level'].default_value=.06
    bs.inputs['Roughness'].default_value=.75
scene.cycles.samples=96;scene.render.filepath=str(OUT/'renders/curl14-reference-angle.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'curl14.blend'));bpy.ops.render.render(write_still=True)
(OUT/'landmarks/curl14-geometry.json').write_text(json.dumps({'undercoat_points_recessed':changed,'visible_curls':'unchanged from curl13','purpose':'controlled undercoat occlusion comparison'},indent=2)+'\n')
print('CURL14_COMPLETE',changed)
