"""Measured front curl guides over a short, scalp-grown undercoat.
Connection map: curl roots raycast onto the actual evaluated scalp with 0.6 mm
embedding; curls overlap the undercoat along their first quarter. Outer guides
retain inferred depths, explicitly unaccepted until profile inspection.
"""
import bpy, math, json, random
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'curl14.blend'))
rng=random.Random(918);scene=bpy.context.scene
for ob in bpy.data.objects:
    if ob.name.startswith('Proof_Curl13_'):ob.hide_render=True
body=bpy.data.objects['AvatarBody'];tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
p=json.loads((OUT/'landmarks/fit05-deformation.json').read_text())['pose']
yaw,pitch,roll=p['yaw'],p['pitch'],p['roll'];scale=p['pixels_per_meter']
r=Vector((math.cos(yaw),math.sin(yaw),0));u=Vector((-math.sin(pitch)*math.sin(yaw),math.sin(pitch)*math.cos(yaw),math.cos(pitch)))
right=r*math.cos(roll)+u*math.sin(roll);down=r*math.sin(roll)-u*math.cos(roll)
outward=right.cross(-down).normalized();center=Vector(p['center'])
def base(x,y):return center+right*((x-p['translation'][0])/scale)+down*((y-p['translation'][1])/scale)
def scalp_depth(x,y):
    q=base(x,y);hit,_,_,_=tree.ray_cast(q+outward*.35,-outward,.7)
    if hit is not None:return (hit-q).dot(outward),True
    # Outside the scalp silhouette, carry the closest projected surface depth
    # rather than moving the guide toward a guessed ellipsoid.
    for dist in [2,4,8,12,18,26,36,50]:
        hits=[]
        for j in range(16):
            angle=j*math.tau/16;v=base(x+dist*math.cos(angle),y+dist*math.sin(angle))
            h,_,_,_=tree.ray_cast(v+outward*.35,-outward,.7)
            if h is not None:hits.append((h-v).dot(outward))
        if hits:return max(hits),False
    raise RuntimeError('No nearby scalp depth')
colors=[(.009,.005,.003),(.019,.010,.006),(.037,.022,.011),(.076,.047,.022),(.15,.097,.045)]
mats=[]
for i,color in enumerate(colors):
    mat=bpy.data.materials.new('Curl18Pigment'+str(i));mat.use_nodes=True
    bs=mat.node_tree.nodes['Principled BSDF'];bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Roughness'].default_value=.50;bs.inputs['Specular IOR Level'].default_value=.22
    mats.append(mat)
# Keep the measured root coverage, but clip unwanted forehead fuzz and thin it.
for ob in bpy.data.objects:
    if not ob.name.startswith('Proof_ScalpField'):continue
    shade=int(ob.name[-1]);ob.data.materials.clear();ob.data.materials.append(mats[shade])
    pos=ob.data.attributes['position'].data;rad=ob.data.attributes['radius'].data
    for j,point in enumerate(pos):
        q=point.vector
        if q.y<-.105 and q.z<1.678:rad[j].value=0
        else:rad[j].value*=.80

def cat(knots,t):
    f=min(t*(len(knots)-1),len(knots)-1-1e-7);j=int(f);s=f-j
    a=knots[max(0,j-1)];b=knots[j];c=knots[min(len(knots)-1,j+1)];d=knots[min(len(knots)-1,j+2)]
    return .5*(2*b+(-a+c)*s+(2*a-5*b+4*c-d)*s*s+(-a+3*b-3*c+d)*s*s*s)
groups=[[] for _ in colors];root_report=[]
guides=json.loads((OUT/'landmarks/hair-guide-traces.json').read_text())['guides']
for g in guides:
    # Four neighboring curl paths distribute coverage through volume.
    for layer in range(3):
        knots=[];depths=[]
        for j,(x,y,_) in enumerate(g['knots']):
            x+=rng.uniform(-2.5,2.5);y+=rng.uniform(-2,2)
            depth,on_head=scalp_depth(x,y);t=j/(len(g['knots'])-1)
            lift=-.0006 if j==0 else .007+.014*math.sin(math.pi*t)+layer*.004
            knots.append(base(x,y)+outward*(depth+lift));depths.append((depth,on_head))
        root_report.append({'guide':g['name'],'layer':layer,'root_hit':depths[0][1]})
        # Depth is smoothed without changing the reference trace's image plane.
        for j in range(1,len(knots)-1):
            old=(knots[j]-center).dot(outward)
            avg=((knots[j-1]+knots[j+1])*.5-center).dot(outward)
            knots[j]+=outward*((avg-old)*.3)
        steps=52;centers=[cat(knots,j/steps) for j in range(steps+1)];frames=[];prev=None
        for j,c in enumerate(centers):
            tangent=(centers[min(steps,j+1)]-centers[max(0,j-1)]).normalized()
            a=tangent.cross(outward).normalized()
            if a.length<.1:a=right.copy()
            if prev is not None and a.dot(prev)<0:a=-a
            frames.append((a,a.cross(tangent).normalized()));prev=a
        width=g['width']/scale*(1.3 if g['width']>4 else .7)
        for strand in range(850):
            angle=rng.random()*math.tau;rad=math.sqrt(rng.random());a=math.cos(angle)*rad*width;b=math.sin(angle)*rad*width*.55
            phase=rng.random()*math.tau;pts=[];tip=rng.uniform(.76,1)
            root_jitter=right*rng.gauss(0,.003)+down*rng.gauss(-.003,.003)
            for j,(c,(side,normal)) in enumerate(zip(centers,frames)):
                t=j/steps
                if t>tip:break
                spread=.85+.15*math.sin(math.pi*t*.85)
                curl=.0016*math.sin(t*17+phase)*math.sin(math.pi*t)
                pts.append(c+side*(a*spread+curl)+normal*(b*spread+curl*.5)+root_jitter*(1-t)**3)
            shade=rng.choices(range(5),[5,6,3,1,.1] if g['shade']<2 else [2,3,4,2,.4])[0]
            # Attach each strand individually; its root may be wider than the guide.
            q=pts[0];hit,_,_,_=tree.ray_cast(q+outward*.12,-outward,.24)
            if hit is not None:
                delta=hit-outward*.0006-q
                for k in range(min(12,len(pts))):pts[k]+=delta*(1-k/12)**2
            groups[shade].append((pts,rng.uniform(.000030,.000058)))
# Inferred side/back volume: true 3D guides rooted on the evaluated skull.
headcenter=Vector((0,-.045,1.651))
def head_surface(n):
    hit,normal,_,_=tree.ray_cast(headcenter+n*.3,-n,.4)
    if hit is None:raise RuntimeError('Back scalp miss')
    return hit,normal
for guide in range(150):
    th=rng.uniform(.9,math.tau-.9);ph=rng.uniform(.25,1.4)
    length=rng.uniform(.45,.9);centers=[];normals=[]
    for j in range(39):
        t=j/38;phi=ph+min(length,1.95-ph)*t;theta=th+.20*math.sin(t*3)
        n=Vector((math.sin(phi)*math.sin(theta),-math.sin(phi)*math.cos(theta),math.cos(phi)))
        hit,normal=head_surface(n)
        if hit.z<1.59:break
        lift=-.0006*(1-t)**12+(.012+.014*math.sin(guide*1.7)**2)*math.sin(math.pi*t)**.8
        centers.append(hit+normal*lift);normals.append(normal)
    if len(centers)!=39:continue
    for strand in range(100):
        a=rng.uniform(-.008,.008);b=rng.uniform(-.003,.003);phase=rng.random()*math.tau;points=[]
        tip=rng.uniform(.8,1)
        for j,(c,normal) in enumerate(zip(centers,normals)):
            t=j/38
            if t>tip:break
            tangent=(centers[min(38,j+1)]-centers[max(0,j-1)]).normalized();across=tangent.cross(normal).normalized()
            points.append(c+across*(a+.001*math.sin(t*15+phase)*math.sin(math.pi*t))+normal*b*math.sin(math.pi*t))
        shade=rng.choices(range(5),[8,5,2,.3,.05])[0]
        groups[shade].append((points,rng.uniform(.000032,.000057)))
# Thin dark scalp surface prevents skin showing through sparse root intervals.
verts=[];faces=[]
for j in range(36):
    for i in range(120):
        theta=i*math.tau/120;end=1.16+.99*((1-math.cos(theta))*.5)**.72
        end-=.23*math.exp(-((min(abs(theta-math.pi*.5),abs(theta-math.pi*1.5)))/.4)**2)
        phi=.001+(end-.001)*j/35
        n=Vector((math.sin(phi)*math.sin(theta),-math.sin(phi)*math.cos(theta),math.cos(phi)))
        hit,normal=head_surface(n);verts.append(hit+normal*.00025)
for j in range(35):
    for i in range(120):faces.append((j*120+i,j*120+(i+1)%120,(j+1)*120+(i+1)%120,(j+1)*120+i))
mesh=bpy.data.meshes.new('Scalp18Surface');mesh.from_pydata(verts,[],faces);mesh.update()
ob=bpy.data.objects.new('Proof_Scalp18Surface',mesh);scene.collection.objects.link(ob)
mat=mats[0].copy();mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.85
mat.node_tree.nodes['Principled BSDF'].inputs['Specular IOR Level'].default_value=.04;mesh.materials.append(mat)
for face in mesh.polygons:face.use_smooth=True
ob.parent=bpy.data.objects['AvatarSkeleton'];ob.parent_type='BONE';ob.parent_bone='head'
bpy.context.view_layer.update();ob.matrix_world.identity()

for shade,entries in enumerate(groups):
    cu=bpy.data.hair_curves.new('Curl18Strands'+str(shade));cu.add_curves([len(pts) for pts,_ in entries])
    positions=[];radii=[]
    for pts,radius in entries:
        for j,q in enumerate(pts):positions.extend(q);radii.append(radius*min(1,.15+j*.25)*max(.012,(1-j/(len(pts)-1))**.7))
    cu.attributes['position'].data.foreach_set('vector',positions)
    cu.attributes.new('radius','FLOAT','POINT').data.foreach_set('value',radii);cu.materials.append(mats[shade])
    ob=bpy.data.objects.new('Proof_Curl18_'+str(shade),cu);scene.collection.objects.link(ob)
    ob.parent=bpy.data.objects['AvatarSkeleton'];ob.parent_type='BONE';ob.parent_bone='head'
    bpy.context.view_layer.update();ob.matrix_world.identity()
(OUT/'landmarks/curl18-geometry.json').write_text(json.dumps({'roots':root_report,'strands':sum(map(len,groups)),'likeness':'pending'},indent=2)+'\n')
scene.cycles.samples=128;scene.render.filepath=str(OUT/'renders/curl18-reference-angle.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'curl18.blend'));bpy.ops.render.render(write_still=True)
print('CURL18_COMPLETE')
