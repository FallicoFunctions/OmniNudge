"""Full 3D swept-quiff groom with overlapping root patches and loose fringe.
Roots overlap the scalp by 2mm; each clump follows a measured 3D head volume.
Curve strands form the visible surface; no opaque ribbons or image projection.
"""
import bpy,math,random,json
from pathlib import Path
from mathutils import Vector
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'master10.blend'))
for ob in bpy.data.objects:
    if ob.name.startswith(('Proof_Fibers','Proof_Hair','Proof_Traced','AvatarHair')):ob.hide_render=True
rng=random.Random(911);strands=[[] for _ in range(5)]
def cat(knots,t):
    f=min(t*(len(knots)-1),len(knots)-1-1e-7);j=int(f);u=f-j
    a=knots[max(0,j-1)];b=knots[j];c=knots[min(j+1,len(knots)-1)];d=knots[min(j+2,len(knots)-1)]
    return .5*(2*b+(-a+c)*u+(2*a-5*b+4*c-d)*u*u+(-a+3*b-3*c+d)*u**3)
def tuft(knots,width,depth,count,light=False):
    knots=list(map(Vector,knots));steps=44
    centers=[cat(knots,j/steps) for j in range(steps+1)]
    frames=[];prev=None
    for j,c in enumerate(centers):
        tangent=(centers[min(steps,j+1)]-centers[max(0,j-1)]).normalized()
        normal=(c-Vector((0,-.025,1.66))).normalized()
        across=tangent.cross(normal).normalized()
        if across.length<.1:across=tangent.cross(Vector((0,1,0))).normalized()
        if prev is not None and across.dot(prev)<0:across=-across
        frames.append((across,across.cross(tangent).normalized()));prev=across
    for i in range(count):
        a=rng.uniform(-width,width);b=rng.uniform(-depth,depth);phase=rng.random()*math.tau
        length=rng.uniform(.82,1);pts=[]
        for j,(c,(across,normal)) in enumerate(zip(centers,frames)):
            t=j/steps
            if t>length:break
            spread=.25+.75*math.sin(math.pi*t*.8)
            pts.append(c+across*(a*spread+.00045*math.sin(t*23+phase))+normal*(b*spread+.0005*math.sin(t*15+phase)))
        shade=rng.choices(range(5),[6,7,3,1,.2] if not light else [2,3,4,3,1])[0]
        strands[shade].append((pts,rng.uniform(.000035,.000065)))
# Dense raised wave: roots at the right-front part, swept across the crown.
for row in range(16):
    f=row/15;y=-.115+f*.15
    for layer in range(4):
        l=layer/3
        root=(.030+l*.016,y,1.688+.032*f)
        knots=[root,(.047,y-.003,1.733+.015*l),(.009,y-.016,1.767+.010*l),
               (-.047,y-.025,1.755+.008*l),(-.084,y-.008,1.707+.012*f),
               (-.075,y+.022,1.677+.022*f)]
        tuft(knots,.006,.0035,150,light=(row<4 and layer==3))
# Loose forelocks descend in irregular S-curves from the principal wave.
for i in range(9):
    f=i/8;off=.007*f
    knots=[(.014,-.105+off,1.744),(-.025,-.135,1.766+off),(-.064,-.155,1.744),
           (-.069,-.169,1.709),(-.060,-.174,1.683-off),(-.080,-.162,1.676-off)]
    tuft(knots,.004,.0025,130,light=i in [1,5])
# Right side combed backward in close waves, revealing the temple and ear.
for i in range(40):
    f=i/39;y=-.105+f*.17;z=1.685+.055*math.sin(math.pi*f*.85)
    knots=[(.044,y,z+.018),(.072,y+.012,z+.006),(.087,y+.027,z-.013),
           (.083,y+.044,z-.036),(.069,y+.055,z-.050)]
    tuft(knots,.005,.0025,120)
# Back/nape coverage with tapered short clumps; avoid covering the ears.
for i in range(80):
    th=rng.uniform(math.pi*.35,math.pi*1.65);start=rng.uniform(.18,.95);knots=[]
    for j in range(6):
        t=j/5;ph=start+(1.98-start)*t;ang=th+.3*math.sin(t*2)
        knots.append((.084*math.sin(ph)*math.sin(ang),-.018-.095*math.sin(ph)*math.cos(ang),1.654+.102*math.cos(ph)))
    tuft(knots,.006,.003,65)
for shade,entries in enumerate(strands):
    cu=bpy.data.hair_curves.new('QuiffStrands'+str(shade));cu.add_curves([len(q) for q,r in entries])
    positions=[];radii=[]
    for points,r in entries:
        for j,q in enumerate(points):
            positions.extend(q);radii.append(r*max(.025,(1-j/(len(points)-1))**.45))
    cu.attributes['position'].data.foreach_set('vector',positions)
    cu.attributes.new('radius','FLOAT','POINT').data.foreach_set('value',radii)
    mat=bpy.data.materials.new('QuiffPigment'+str(shade));mat.use_nodes=True;tree=mat.node_tree
    bs=tree.nodes.new('ShaderNodeBsdfHairPrincipled');bs.parametrization='MELANIN'
    bs.inputs['Melanin'].default_value=[.97,.94,.9,.8,.63][shade]
    bs.inputs['Melanin Redness'].default_value=.14;bs.inputs['Roughness'].default_value=.42
    bs.inputs['Radial Roughness'].default_value=.45;bs.inputs['Tint'].default_value=(.20,.17,.13,1)
    tree.links.new(bs.outputs[0],tree.nodes['Material Output'].inputs['Surface']);cu.materials.append(mat)
    ob=bpy.data.objects.new('Proof_Quiff'+str(shade),cu);bpy.context.scene.collection.objects.link(ob)
    ob.parent=bpy.data.objects['AvatarSkeleton'];ob.parent_type='BONE';ob.parent_bone='head'
    bpy.context.view_layer.update();ob.matrix_world.identity()
scene=bpy.context.scene;scene.cycles.samples=48
scene.render.filepath=str(OUT/'renders/quiff11-reference-angle.png');bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'quiff11.blend'))
print('QUIFF11_COMPLETE',sum(len(s) for s in strands))
