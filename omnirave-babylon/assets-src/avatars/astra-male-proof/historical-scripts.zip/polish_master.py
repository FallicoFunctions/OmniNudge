"""Local material and scalp-contact pass on the preserved native hair master.
Connection map: penetrating front strands move to the measured skin surface
plus 1mm clearance. The underlying body, rig and shared facial topology remain.
"""
import bpy,math,json,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'fiber09.blend'))
scene=bpy.context.scene;body=bpy.data.objects['AvatarBody']
tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
pose=json.loads((OUT/'landmarks/fit05-deformation.json').read_text())['pose']
yaw,pitch=pose['yaw'],pose['pitch'];outward=Vector((math.sin(yaw)*math.cos(pitch),-math.cos(yaw)*math.cos(pitch),math.sin(pitch)))
fixed=0
for ob in bpy.data.objects:
    if not ob.name.startswith('Proof_Fibers'):continue
    for pt in ob.data.attributes['position'].data:
        q=pt.vector.copy()
        if q.z<1.62 or q.y>.015:continue
        hit,normal,index,distance=tree.ray_cast(q+outward*.12,-outward,.24)
        if hit is not None:
            behind=(hit-q).dot(outward)
            if behind>-.0007 and behind<.04:
                pt.vector=q+outward*(behind+.001);fixed+=1
    mat=ob.data.materials[0]
    for n in mat.node_tree.nodes:
        if n.type=='BSDF_HAIR_PRINCIPLED':
            n.parametrization='MELANIN'
            shade=int(ob.name.replace('Proof_Fibers',''))
            n.inputs['Melanin'].default_value=[.91,.88,.84,.78,.65,.5][shade]
            n.inputs['Melanin Redness'].default_value=.25
            n.inputs['Tint'].default_value=(.45,.32,.24,1)
            n.inputs['Roughness'].default_value=.48
            n.inputs['Radial Roughness'].default_value=.45
            if 'Reflection' in n.inputs:n.inputs['Reflection'].default_value=.65
            n.inputs['Random Roughness'].default_value=.10
# Preserve surface detail while attenuating the inherited stubble-like contrast.
skin=bpy.data.materials['AvatarSkin'];tree=skin.node_tree;bs=tree.nodes['Principled BSDF']
incoming=bs.inputs['Base Color'].links[0].from_socket
mix=tree.nodes.new('ShaderNodeMixRGB');mix.blend_type='MIX';mix.inputs[0].default_value=.48
mix.inputs[2].default_value=(.28,.163,.108,1);tree.links.new(incoming,mix.inputs[1]);tree.links.new(mix.outputs[0],bs.inputs['Base Color'])
bs.inputs['Roughness'].default_value=.39
# The source eyelashes are much longer than those in the male reference.
bpy.data.objects['AvatarEyelashes'].hide_render=True
scene.cycles.samples=64;scene.render.filepath=str(OUT/'renders/master10-reference-angle.png')
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'master10.blend'))
(OUT/'landmarks/master10-contact.json').write_text(json.dumps({'front_strand_points_corrected':fixed,'skin_mix':.48,'eyelashes':'source strip hidden; final lash authoring pending','scope':'likeness master, not runtime asset'},indent=2)+'\n')
print('MASTER10_COMPLETE',fixed)
