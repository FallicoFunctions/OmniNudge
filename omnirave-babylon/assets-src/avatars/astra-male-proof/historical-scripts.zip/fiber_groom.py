"""Fine curve-strand groom for likeness master, to be baked to game hair later.
Connection map: source scalp volume underlies roots. Curl guides share root
regions with the scalp strands. Head bone parenting preserves the rest transform.
"""
import bpy,json,math,random
from mathutils import Vector

def build(out):
    rng=random.Random(910)
    for o in bpy.data.objects:
        if o.name.startswith(('Proof_HairCards','Proof_Traced','AvatarHair')):o.hide_render=True
    cap=bpy.data.objects.get('Proof_HairVolume')
    if cap:cap.hide_render=True
    p=json.loads((out/'landmarks/fit05-deformation.json').read_text())['pose']
    guides=json.loads((out/'landmarks/hair-guide-traces.json').read_text())['guides']
    yaw,pitch,roll=p['yaw'],p['pitch'],p['roll'];scale=p['pixels_per_meter']
    r=Vector((math.cos(yaw),math.sin(yaw),0));u=Vector((-math.sin(pitch)*math.sin(yaw),math.sin(pitch)*math.cos(yaw),math.cos(pitch)))
    right=r*math.cos(roll)+u*math.sin(roll);down=r*math.sin(roll)-u*math.cos(roll)
    outward=right.cross(-down).normalized();center=Vector(p['center'])
    def world(q):
        x,y,d=q;return center+right*((x-p['translation'][0])/scale)+down*((y-p['translation'][1])/scale)+outward*d
    colors=[(.013,.006,.003),(.022,.010,.005),(.036,.018,.008),(.062,.034,.015),(.105,.063,.029),(.17,.115,.054)]
    mats=[];curves=[];strand_data=[[] for _ in colors]
    for i,color in enumerate(colors):
        mat=bpy.data.materials.new('FiberPigment'+str(i));mat.use_nodes=True
        tree=mat.node_tree;bs=tree.nodes.new('ShaderNodeBsdfHairPrincipled');bs.parametrization='COLOR'
        bs.inputs['Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=.38
        bs.inputs['Radial Roughness'].default_value=.42
        tree.links.new(bs.outputs[0],tree.nodes['Material Output'].inputs['Surface'])
        cu=bpy.data.hair_curves.new('FiberCurves'+str(i))
        ob=bpy.data.objects.new('Proof_Fibers'+str(i),cu);bpy.context.scene.collection.objects.link(ob);cu.materials.append(mat)
        rig=bpy.data.objects['AvatarSkeleton'];ob.parent=rig;ob.parent_type='BONE';ob.parent_bone='head'
        # Keep the constructed rest coordinates while inheriting future head motion.
        bpy.context.view_layer.update();ob.matrix_world.identity()
        curves.append(cu);mats.append(mat)
    def strand(points,shade,radius):
        strand_data[shade].append((points,radius))
    def cat(knots,t):
        f=min(t*(len(knots)-1),len(knots)-1-1e-7);j=int(f);s=f-j
        a=knots[max(0,j-1)];b=knots[j];c=knots[min(len(knots)-1,j+1)];d=knots[min(len(knots)-1,j+2)]
        return .5*(2*b+(-a+c)*s+(2*a-5*b+4*c-d)*s*s+(-a+3*b-3*c+d)*s*s*s)
    def tuft(knots,width,shade,count):
        steps=48
        centers=[cat(knots,j/steps) for j in range(steps+1)]
        tangents=[(centers[min(steps,j+1)]-centers[max(0,j-1)]).normalized() for j in range(steps+1)]
        frames=[];prev=None
        for tangent in tangents:
            side=tangent.cross(outward).normalized()
            if side.length<.1:side=tangent.cross(Vector((1,0,0))).normalized()
            if prev and side.dot(prev)<0:side=-side
            frames.append((side,side.cross(tangent).normalized()));prev=side
        for k in range(count):
            angle=rng.uniform(0,math.tau);rad=math.sqrt(rng.random());phase=rng.uniform(0,math.tau)
            a=math.cos(angle)*rad*width*.5;b=math.sin(angle)*rad*width*.33
            tip=rng.uniform(.89,1);pts=[]
            for j,(c,(side,normal)) in enumerate(zip(centers,frames)):
                t=j/steps
                if t>tip:break
                spread=(.5+.5*math.sin(math.pi*t))*(1-.45*t**4)
                frizz=.00035*math.sin(t*23+phase)+.00018*math.sin(t*43+phase)
                pts.append(c+side*(a*spread+frizz)+normal*(b*spread+frizz*.6))
            pigment=rng.choices(range(6),[3,5,4,2,1,.2] if shade<2 else [1,2,3,4,3,1])[0]
            strand(pts,pigment,rng.uniform(.65,1.2))
    for g in guides:
        knots=[]
        for j,point in enumerate(g['knots']):
            x,y,olddepth=point;base=world((x,y,0))
            # Solve the viewing ray against the head volume. Reference traces
            # determine image position; scalp intersection constrains their depth.
            radii=Vector((.085,.104,.092));head=Vector((0,-.03,1.65))
            a=Vector(tuple(outward[i]/radii[i] for i in range(3)))
            b=Vector(tuple((base-head)[i]/radii[i] for i in range(3)))
            A=a.dot(a);B=2*a.dot(b);C=b.dot(b)-1;disc=B*B-4*A*C
            depth=(-B+math.sqrt(max(0,disc)))/(2*A)
            t=j/(len(g['knots'])-1)
            lift=.002+.013*math.sin(math.pi*t)
            # Front root is slightly embedded; free fringe tips may leave scalp.
            if j==0:lift=-.002
            if g['width']<4:lift+=.005*t
            knots.append(base+outward*(depth+lift))
        tuft(knots,g['width']/scale*1.55,g['shade'],450 if g['width']>4 else 180)
    # Overlapping clumps fill the crown between measured front guides and inferred back.
    for i in range(110):
        theta=rng.uniform(-math.pi,math.pi)
        start=rng.uniform(.12,.95)
        end=1.20+.85*((1-math.cos(theta))*.5)**.65
        knots=[]
        for j in range(6):
            t=j/5;ph=start+(end-start)*t;th=theta+.55*t
            n=Vector((math.sin(ph)*math.sin(th),-math.sin(ph)*math.cos(th),math.cos(ph)))
            q=Vector((n.x*.082,n.y*.095-.025,n.z*.107+1.646))
            q+=n*(.004+.009*math.sin(math.pi*t))
            # Gentle S curl around the sides instead of straight combed stripes.
            q.x+=.004*math.sin(t*8+i)*math.sin(math.pi*t)
            knots.append(q)
        tuft(knots,.013,0,90)
    for cu,entries in zip(curves,strand_data):
        cu.add_curves([len(points) for points,r in entries])
        positions=[];radii=[]
        for points,radius in entries:
            for j,q in enumerate(points):
                positions.extend(q)
                radii.append(.000060*radius*min(1,.35+j*.3)*max(.035,(1-j/(len(points)-1))**.4))
        cu.attributes['position'].data.foreach_set('vector',positions)
        attr=cu.attributes.new('radius','FLOAT','POINT');attr.data.foreach_set('value',radii)
    total=sum(len(c.curves) for c in curves)
    (out/'landmarks/fiber-groom-report.json').write_text(json.dumps({'seed':910,'strands':total,'purpose':'native hair curves authoring master; runtime bake pending'},indent=2)+'\n')
    print('FIBER_STRANDS',total)
