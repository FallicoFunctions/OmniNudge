"""Bounded likeness experiment on jaw, buccal cheek and mouth relaxation.
Connection map: all changes remain within the continuous head/body topology;
head/neck seam unchanged. Hair and eyeballs retain the control geometry.
"""
import bpy,math,json
from pathlib import Path
from mathutils import Vector
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'curl18.blend'))
body=bpy.data.objects['AvatarBody']
key=body.shape_key_add(name='Jaw_mouth_relaxation_19',from_mix=True)
for k in body.data.shape_keys.key_blocks[1:]:k.value=0
key.value=1
def gauss(v,c,s):return math.exp(-.5*sum(((v[i]-c[i])/s[i])**2 for i in range(3)))
changes=[]
for v in key.data:
    q=v.co.copy();x,y,z=q
    if z<1.48 or z>1.63 or y>-.055:continue
    ax=abs(x);sgn=1 if x>=0 else -1;delta=Vector((0,0,0))
    # Narrow the broad lower jaw and gently hollow the buccal cheek.
    jaw=gauss(Vector((ax,y,z)),(.041,-.106,1.523),(.030,.040,.025))
    cheek=gauss(Vector((ax,y,z)),(.049,-.124,1.574),(.017,.029,.021))
    delta.x-=sgn*(.0022*jaw+.0010*cheek)
    delta.y+=.0017*cheek
    # Relax the mouth corners and reduce the parted-lip gap slightly.
    corner=gauss(Vector((ax,y,z)),(.021,-.145,1.553),(.008,.017,.008))
    lower=gauss(q,(0,-.151,1.545),(.021,.019,.0048))
    upper=gauss(q,(0,-.151,1.560),(.016,.019,.0048))
    delta.z+=.0010*corner+.0008*lower-.00035*upper
    v.co+=delta;changes.append(delta.length)
# The reference has a darker brown iris than the source hazel material.
iris=bpy.data.materials['AvatarIrisHazel'].node_tree.nodes['Principled BSDF']
iris.inputs['Base Color'].default_value=(.040,.022,.012,1)
# Calm the orange cast without removing the inherited texture variation.
skin=bpy.data.materials['AvatarSkin'];tree=skin.node_tree;bs=tree.nodes['Principled BSDF']
incoming=bs.inputs['Base Color'].links[0].from_socket
mix=tree.nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1
mix.inputs[2].default_value=(.92,.96,1.0,1);tree.links.new(incoming,mix.inputs[1]);tree.links.new(mix.outputs[0],bs.inputs['Base Color'])
bs.inputs['Roughness'].default_value=.46
scene=bpy.context.scene;scene.cycles.samples=128
scene.render.filepath=str(OUT/'renders/face19-reference-angle.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'face19.blend'));bpy.ops.render.render(write_still=True)
(OUT/'landmarks/face19-sculpt.json').write_text(json.dumps({'max_displacement_m':max(changes),'modified_vertices':len(changes),'control':'curl18','likeness':'unaccepted','mouth_jaw_only':True},indent=2)+'\n')
print('FACE19_COMPLETE')
