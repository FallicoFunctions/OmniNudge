"""Measured front curl guides over a short, scalp-grown undercoat.
Connection map: curl roots raycast onto the actual evaluated scalp with 0.6 mm
embedding; curls overlap the undercoat along their first quarter. Outer guides
retain inferred depths, explicitly unaccepted until profile inspection.
"""
import bpy, math, json, random
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parents[2]/'assets-src/avatars/astra-male-proof'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'scalp12.blend'))
rng=random.Random(913);scene=bpy.context.scene
body=bpy.data.objects['AvatarBody'];tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
p=json.loads((OUT/'landmarks/fit05-deformation.json').read_text())['pose']
yaw,pitch,roll=p['yaw'],p['pitch'],p['roll'];scale=p['pixels_per_meter']
r=Vector((math.cos(yaw),math.sin(yaw),0));u=Vector((-math.sin(pitch)*math.sin(yaw),math.sin(pitch)*math.cos(yaw),math.cos(pitch)))
right=r*math.cos(roll)+u*math.sin(roll);down=r*math.sin(roll)-u*math.cos(roll)
outward=right.cross(-down).normalized();center=Vector(p['center'])
def base(x,y):return center+right*((x-p['translation'][0])/scale)+down*((y-p['translation'][1])/scale)
def scalp_depth(x,y):
    q=base(x,y);hit,_,_,_=tree.ray_cast(q+outward*.35,-outward,.7)
    if hit is not None:return (hit-q).dot(outward),True
    # Outside the scalp silhouette, carry the closest projected surface depth
    # rather than moving the guide toward a guessed ellipsoid.
    for dist in [2,4,8,12,18,26,36,50]:
        hits=[]
        for j in range(16):
            angle=j*math.tau/16;v=base(x+dist*math.cos(angle),y+dist*math.sin(angle))
            h,_,_,_=tree.ray_cast(v+outward*.35,-outward,.7)
            if h is not None:hits.append((h-v).dot(outward))
        if hits:return max(hits),False
    raise RuntimeError('No nearby scalp depth')
colors=[(.009,.005,.003),(.019,.010,.006),(.037,.022,.011),(.076,.047,.022),(.15,.097,.045)]
mats=[]
for i,color in enumerate(colors):
    mat=bpy.data.materials.new('Curl13Pigment'+str(i));mat.use_nodes=True
    bs=mat.node_tree.nodes['Principled BSDF'];bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Roughness'].default_value=.50;bs.inputs['Specular IOR Level'].default_value=.22
    mats.append(mat)
# Keep the measured root coverage, but clip unwanted forehead fuzz and thin it.
for ob in bpy.data.objects:
    if not ob.name.startswith('Proof_ScalpField'):continue
    shade=int(ob.name[-1]);ob.data.materials.clear();ob.data.materials.append(mats[shade])
    pos=ob.data.attributes['position'].data;rad=ob.data.attributes['radius'].data
    for j,point in enumerate(pos):
        q=point.vector
        if q.y<-.105 and q.z<1.678:rad[j].value=0
        else:rad[j].value*=.80

def cat(knots,t):
    f=min(t*(len(knots)-1),len(knots)-1-1e-7);j=int(f);s=f-j
    a=knots[max(0,j-1)];b=knots[j];c=knots[min(len(knots)-1,j+1)];d=knots[min(len(knots)-1,j+2)]
    return .5*(2*b+(-a+c)*s+(2*a-5*b+4*c-d)*s*s+(-a+3*b-3*c+d)*s*s*s)
groups=[[] for _ in colors];root_report=[]
guides=json.loads((OUT/'landmarks/hair-guide-traces.json').read_text())['guides']
for g in guides:
    # Four neighboring curl paths distribute coverage through volume.
    for layer in range(4):
        knots=[];depths=[]
        for j,(x,y,_) in enumerate(g['knots']):
            x+=rng.uniform(-1.5,1.5);y+=rng.uniform(-1,1)
            depth,on_head=scalp_depth(x,y);t=j/(len(g['knots'])-1)
            lift=-.0006 if j==0 else .006+.010*math.sin(math.pi*t)+layer*.002
            knots.append(base(x,y)+outward*(depth+lift));depths.append((depth,on_head))
        root_report.append({'guide':g['name'],'layer':layer,'root_hit':depths[0][1]})
        # Depth is smoothed without changing the reference trace's image plane.
        for j in range(1,len(knots)-1):
            old=(knots[j]-center).dot(outward)
            avg=((knots[j-1]+knots[j+1])*.5-center).dot(outward)
            knots[j]+=outward*((avg-old)*.3)
        steps=52;centers=[cat(knots,j/steps) for j in range(steps+1)];frames=[];prev=None
        for j,c in enumerate(centers):
            tangent=(centers[min(steps,j+1)]-centers[max(0,j-1)]).normalized()
            a=tangent.cross(outward).normalized()
            if a.length<.1:a=right.copy()
            if prev is not None and a.dot(prev)<0:a=-a
            frames.append((a,a.cross(tangent).normalized()));prev=a
        width=g['width']/scale*.65
        for strand in range(240):
            angle=rng.random()*math.tau;rad=math.sqrt(rng.random());a=math.cos(angle)*rad*width;b=math.sin(angle)*rad*width*.55
            phase=rng.random()*math.tau;pts=[];tip=rng.uniform(.88,1)
            for j,(c,(side,normal)) in enumerate(zip(centers,frames)):
                t=j/steps
                if t>tip:break
                spread=.4+.6*math.sin(math.pi*t*.85)
                curl=.0009*math.sin(t*17+phase)*math.sin(math.pi*t)
                pts.append(c+side*(a*spread+curl)+normal*(b*spread+curl*.5))
            shade=rng.choices(range(5),[5,6,3,1,.1] if g['shade']<2 else [2,3,4,2,.4])[0]
            groups[shade].append((pts,rng.uniform(.000035,.000065)))
for shade,entries in enumerate(groups):
    cu=bpy.data.hair_curves.new('Curl13Strands'+str(shade));cu.add_curves([len(pts) for pts,_ in entries])
    positions=[];radii=[]
    for pts,radius in entries:
        for j,q in enumerate(pts):positions.extend(q);radii.append(radius*max(.025,(1-j/(len(pts)-1))**.45))
    cu.attributes['position'].data.foreach_set('vector',positions)
    cu.attributes.new('radius','FLOAT','POINT').data.foreach_set('value',radii);cu.materials.append(mats[shade])
    ob=bpy.data.objects.new('Proof_Curl13_'+str(shade),cu);scene.collection.objects.link(ob)
    ob.parent=bpy.data.objects['AvatarSkeleton'];ob.parent_type='BONE';ob.parent_bone='head'
    bpy.context.view_layer.update();ob.matrix_world.identity()
(OUT/'landmarks/curl13-geometry.json').write_text(json.dumps({'roots':root_report,'strands':sum(map(len,groups)),'likeness':'pending'},indent=2)+'\n')
scene.cycles.samples=96;scene.render.filepath=str(OUT/'renders/curl13-reference-angle.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'curl13.blend'));bpy.ops.render.render(write_still=True)
print('CURL13_COMPLETE')
